<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        header('Content-Type: application/json');
        date_default_timezone_set('Asia/Jakarta');
        error_reporting(E_ALL);
        ini_set('Display Error', 1);
    }

    public function getUser()
    {
        $user_id = $this->input->post('user_id');

        $response = array();
        $this->db->where('id_user', $user_id);
        $q = $this->db->get('tb_users');

        if ($q->num_rows() > 0) {
            $response['status'] = 200;
            $response['message'] = 'Akun Ditemukan';
            foreach ($q->result() as $row);
            $response['data']['id'] = (int)$row->id_user;
            $response['data']['fullname'] = $row->fullname;
            $response['data']['email'] = $row->email;
        } else {
            $response['status'] = 404;
            $response['message'] = 'Akun Tidak Ditemukan';
        }

        echo json_encode($response);
    }

    public function login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $response = array();
        $this->db->where('email', $email);
        $this->db->where('password', md5($password));
        $q = $this->db->get('tb_users');

        if ($q->num_rows() > 0) {
            $response['status'] = 200;
            $response['message'] = 'Login Berhasil';
            foreach ($q->result() as $row);
            $response['data']['id'] = (int)$row->id_user;
            $response['data']['fullname'] = $row->fullname;
            $response['data']['email'] = $row->email;
        } else {
            $response['status'] = 404;
            $response['message'] = 'Login Gagal';
        }

        echo json_encode($response);
    }

    public function register()
    {
        $full_name = $this->input->post('full_name');
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $response = array();
        $this->db->where('email', $email);
        $q = $this->db->get('tb_users');

        if ($q->num_rows() > 0) {
            $response['status'] = 404;
            $response['message'] = 'Email telah terdaftar';
        } else {
            $data['fullname'] = $this->db->escape_str($full_name);
            $data['email'] = $this->db->escape_str($email);
            $data['password'] = md5($password);
            $query_saved = $this->db->insert('tb_users', $data);
            if ($query_saved) {
                $response['status'] = 200;
                $response['message'] = 'Berhasil mendaftar';
            } else {
                $response['status'] = 404;
                $response['message'] = 'Gagal mendaftar';
            }
        }

        echo json_encode($response);
    }

    public function getNews()
    {
        $this->load->helper('url');
        $this->db->select('*');
        $this->db->from('tb_news');
        $this->db->join('tb_category', 'tb_category.id_category = tb_news.category');
        $this->db->join('tb_users', 'tb_users.id_user = tb_news.author');
        $this->db->order_by('tb_news.id_news', 'DESC');
        $getNews = $this->db->get();
        $response = array();
        foreach ($getNews->result() as $row) {
            array_push(
                $response,
                array(
                    'news_id' => (int)$row->id_news,
                    'news_title' => $row->title,
                    'news_content' => $row->content,
                    'news_banner' => base_url() . 'images/' . $row->banner,
                    'news_category' => array(
                        'category_id' => (int)$row->category,
                        'category_name' => $row->category_name,
                    ),
                    'news_author' => array(
                        'author_id' => (int)$row->id_user,
                        'author_name' => $row->fullname,
                        'author_email' => $row->email,
                    )
                )
            );
        }
        echo json_encode($response);
    }

    public function getNewsInfo()
    {
        $getNews = $this->db->get('tb_category');
        $response = array();
        foreach ($getNews->result() as $row) {
            $response['categories'][] = array(
            'category_id' => $row->id_category,
            'category_name' => $row->category_name,
            );
        }
        echo json_encode($response);
    }

    public function addNews()
    {
        $config['upload_path'] = './images/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['encrypt_name'] = true;
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('banner')) {
            $response['status'] = 404;
            $response['message'] = 'Post Gagal';
            echo json_encode($response);
            die();
        }
        $news_title = $this->input->post('news_title');
        $news_content = $this->input->post('news_content');
        $news_category = $this->input->post('news_category');
        $news_author = $this->input->post('news_author');
        $response = array();
        $data = array(
            'title' => $this->db->escape_str($news_title),
            'content' => $this->db->escape_str($news_content),
            'banner' => $this->upload->file_name,
            'category' => $this->db->escape_str($news_category),
            'author' => $this->db->escape_str($news_author)
        );
        if ($this->db->insert('tb_news', $data)) {
            $response['status'] = 200;
            $response['message'] = 'Post Berhasil';
        } else {
            $response['status'] = 404;
            $response['message'] = 'Post Gagal';
        }
        echo json_encode($response);
    }

    public function deleteNews()
    {
        $news_id = $this->input->post('news_id');
         $response['id'] = $news_id;

        $this->db->select('banner');
        $this->db->where('id_news', $news_id);
        $query = $this->db->get('tb_news');
        if ($query->num_rows() > 0) {
            $bannerFile = $query->result();
            if (file_exists('./images/' . $bannerFile[0]->banner)) {
                unlink('./images/' . $bannerFile[0]->banner);
            }
            $this->db->where('id_news', $news_id);
            $delete = $this->db->delete('tb_news');
            if ($delete) {
                $response['status'] = 200;
                $response['message'] = 'Hapus Berhasil';
            } else {
                $response['status'] = 404;
                $response['message'] = 'Hapus Gagal';
            }
        } else {
            $response['status'] = 404;
            $response['message'] = 'Data tidak ditemukan';
        }

        echo json_encode($response);
    }

    public function editNews()
    {
        $news_id = $this->input->post('news_id');
        $news_title = $this->input->post('news_title');
        $news_content = $this->input->post('news_content');
        $news_category = $this->input->post('news_category');
        $new_data = array(
            'title' => $news_title,
            'content' => $news_content,
            'category' => $news_category,
        );
        $this->db->where('id_news', $news_id);
        $edit = $this->db->update('tb_news', $new_data);
        if ($edit) {
            $response['status'] = 200;
            $response['message'] = 'Edit Berhasil';
        } else {
            $response['status'] = 404;
            $response['message'] = 'Edit Gagal';
        }
        echo json_encode($response);
    }

    
}